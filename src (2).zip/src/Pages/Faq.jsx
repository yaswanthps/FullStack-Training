import React from 'react'

const Faq = () => {
  return (
    <div>
      <h1>Faq Page</h1>
    </div>
  )
}

export default Faq
